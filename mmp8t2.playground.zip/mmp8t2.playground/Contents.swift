

import Foundation

// Matthew Patterson Project 1
/* PROJECT ONE PLAYGROUND INSTRUCTIONS
 *  - You can add any other functions you want to this file.
 *  - But I must be able to use the functions calls that are commented out to get your results.
 *  - You will to research some of the capabilities of Swift (and potentially Foundation) to complete this playground
*/


/* Problem 1
 Write a function that:
 - takes in an Array of Ints
 - separates them into odd and even numbers
 - sorts both lists of numbers
 - and then returns the sorted evens and odds as a tuple
 
 Notes:
 - Research how to return multiple values (as a named tuple) from Swift functions
 - Do not manually sort the integers; find a better way!
 */



func sortedEvenOdd(numbers: [Int]) -> (evens: [Int], odds: [Int]) {
    var evens = numbers.filter{ $0 % 2 != 0}
    evens.sort()
    var odds = numbers.filter{ $0 % 2 == 0}
    odds.sort()
    return (odds, evens)
}


let sortedNumbers = sortedEvenOdd(numbers: [0, 9, 3, 7, 8, 15, 11, 2, 20])
print(sortedNumbers.evens)  // [0, 2, 8, 20]
print(sortedNumbers.odds)   // [3, 7, 9, 11, 15]



/* Problem 2
    Write a function that:
        - takes in two parameters: an Array of Strings and a String to find
        - locates the index of the string to find, if it exists in the array
        - returns an optional string one position later in the array than the string to find
    Notes: 
        - if the string to find is at the end of the array, return the string at the beginning of the array
        - consult Apple's documentation to find a method on Array that will locate the index of a given element - do not loop through the array to find it.
        - if you encounter any optional values, unwrap them properly
 */


func findNextItem(from testString: String, in testArray: [String]) ->  String? {
    if let index = testArray.firstIndex(of: testString) {
    
    if index >= 0, index < testArray.count {
        return testArray[index]
    }
    
    return nil
    }
    return nil
}
//    }
 //   if index >= 0 && index < bucket.count {
   //     return bucket[index + 1]
  //  }
  //  else {
  //      return bucket[0]
  //  }
    

//}

let bucketList = ["Travel to Antarctica", "Climb Mount Everest", "Run a marathon", "Write a book", "Build an iOS app"]
let item1 = findNextItem(from: "Write a book", in: bucketList)
let item2 = findNextItem(from: "Build an iOS app", in: bucketList)
let item3 = findNextItem(from: "Run a marathon", in: [])
//
print(item1!) // "Build an iOS app"
print(item2!) // "Travel to Antarctica"
print(item3)  // nil



/* Problem 3
   Write a function that generates a url string for making an HTTP GET request. It should match the call signature of the example calls below.
    - Look at the example output for how you need to construct your function.
    - Do not worry about any encoding issues; if there is a space in a parameter's key or value, just remove it
    - I will not use any harder examples to grade than in the example calls below
    - The order the parameters appear in the query string is not important
*/

func httpGetUrl(baseUrl: String, parameters: [String:String]) -> String {
    var url = "\(baseUrl)?"
    for (category, value) in parameters{
        
    url.append("\(category)=\(value)&")
    }
    url.remove(at: url.index(before: url.endIndex))
    let removeSpaces = String(url.filter {!" \n".contains($0)})
    
    return removeSpaces
}


let url1 = httpGetUrl(baseUrl: "http://boardgames.com/game", parameters: ["Genre":"Strategy", "name":"Settlers Of Catan", "User Rating":"high"])
let url2 = httpGetUrl(baseUrl: "http://boardgames.com/game", parameters: [:])
//
//// Sample Output: query params can be in any order
//print(url1)  // "http://boardgames.com/game?genre=strategy&name=settlersofcatan&userrating=high"  
//print(url2)  // "http://boardgames.com/game"



/* Problem 4
    Write a function that takes in a camel-case string and returns an integer representing the number of words in the string
    Notes:
    - Assume all input will contain only letters, and the string will be a valid camel-cased phrase
    - Do not loop through the array manually.
*/

func camelCaseWordCount (for testString: String) -> Int {
    
    let capitals = testString.filter { "ABCDEFGHIJKLMNOPQRSTUVWXYZ".contains($0)}
    let result = capitals.count + 1
    return result
}



//// Sample Input
let camelCasePhraseOne = "camelCasePhraseOne"
let camelCasePhraseTwo = "aMuchLongerCamelCasePhraseThatIsWayWayWayMoreFunToTest"
//
//// Sample Output
print(camelCaseWordCount(for: camelCasePhraseOne))    // 4
print(camelCaseWordCount(for: camelCasePhraseTwo))    // 15



/* Problem 5
    Write a function that takes in two positive integers and prints every prime number between (and including) them
 */

func printPrimes (from start: Int, to end: Int) {
    
    let numbers = start...end
    
    for number in numbers {
        var prime = "true"
        if number == 2 {
            print(number, terminator: " ")
        }
        if number > 2 {
            for iterator in 2 ... (number - 1) {
                if number % iterator == 0 {
                    prime = "false"
                }
                
                }
            if prime == "true" {
                print(number, terminator: " ")
            }
            
        }
}
}
// Sample Input
printPrimes(from: 0, to: 100) // [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97]

